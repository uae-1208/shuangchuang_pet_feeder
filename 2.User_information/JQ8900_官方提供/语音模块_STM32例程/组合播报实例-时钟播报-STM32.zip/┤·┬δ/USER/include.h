#ifndef __INCLUDE_H_
#define __INCLUDE_H_

#include "stm32f10x.h"
#include "delay.h"
#include "ds1302.h"
#include "oled.h"
#include "usart.h"	
#include "JQ8X00.h"
  

#endif
