#ifndef __DELAY_H_
#define __DELAY_H_

void delay_us(uint16_t us_time);
void delay_ms(uint16_t us_time);

#endif