#ifndef __PUBLIC_H_
#define __PUBLIC_H_

/*******************�궨����*********************/
typedef bit                   BIT;
typedef unsigned char         uint_8;
typedef unsigned int          UINT16;
typedef unsigned long         UINT32;

typedef unsigned char         uint8_t;
typedef unsigned int          uint16_t;
typedef unsigned long         uint32_t;

#define BufferLen 20            //���ڽ��ճ���

extern bit BIT_TMP;

/*******************ͷ�ļ�������*********************/
#include "N76E003.h"
#include "SFR_Macro.h"
#include "Function_define.h"
#include "UART0.h"
#include "JQ8X00.h"
#include "delay.h"
#include "string.h"

#endif