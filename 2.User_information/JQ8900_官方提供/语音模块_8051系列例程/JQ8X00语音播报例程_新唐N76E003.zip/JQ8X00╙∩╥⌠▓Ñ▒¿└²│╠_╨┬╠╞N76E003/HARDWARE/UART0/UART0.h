#ifndef __UART0_H_
#define __UART0_H_

void  InitialUART0_Timer1(UINT32 u32Baudrate); //T1M = 1, SMOD = 1
void UART0_SendCode(char *s,uint_8 Len);

#endif